import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
import java.io.*;
public class CreateQuiz extends JFrame implements ItemListener,ActionListener{
	int n,count = 1,finish = 0;
	JLabel jl1,jl2,jl3,jl;
	JTextField jt1,jt,al1,al2,al3,al4;;
	Checkbox rb1,rb2,rb3,rb4;
	JButton b1,b2,jb,b,insertb1;
	int permission = 0;
	String str = " ",str1 = " ";
	String answer = " ";
	CreateQuiz() throws IOException {
		Start();
		jl1=new JLabel("Give me Question ->" +" "+ count);
		jl2=new JLabel(str);
		jl3=new JLabel(str1);
		jt1 = new JTextField();
		b1 = new JButton("Next");
		b2 = new JButton("Finish");
		b = new JButton("Ok");
		al1 = new JTextField(" ");
		al2 = new JTextField(" ");
		al3 = new JTextField(" ");
		al4 = new JTextField(" ");
		insertb1 = new JButton("Insert Options");
		add(al1); add(al2); add(al3); add(al4);
		add(insertb1);
		CheckboxGroup cg = new CheckboxGroup();
		//cg.setFont(f);
		rb1 = new Checkbox("Option1",cg,false);
		rb2 = new Checkbox("Option2",cg,false);
		rb3 = new Checkbox("Option3",cg,false);
		rb4 = new Checkbox("Option4",cg,false);
		
		add(rb1);
		add(rb2);
		add(rb3);
		add(rb4);
		rb1.addItemListener(this);
		rb3.addItemListener(this);
		rb2.addItemListener(this);
		rb4.addItemListener(this);
			
		add(b1); add(b2); add(jl1); add(jt1); add(jl2);
		
		insertb1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rb1.setLabel(al1.getText());
				al1.setText("");
				rb2.setLabel(al2.getText());
				al2.setText("");
				rb3.setLabel(al3.getText());
				al3.setText("");
				rb4.setLabel(al4.getText());
				al4.setText("");
				
			}
		});
			
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
			//// Storing question
				String text = jt1.getText();
				ArrayList<String> arrayList = new ArrayList<String>();
				arrayList.add(rb1.getLabel());
				arrayList.add(rb2.getLabel());
				arrayList.add(rb3.getLabel());
				arrayList.add(rb4.getLabel());
				try{
					FileWriter fw = new FileWriter(str1 + ".txt",true);
					PrintWriter bw = new PrintWriter(fw);
					bw.println(text+"-" + arrayList.get(0) +"-" + arrayList.get(1)+"-" + arrayList.get(2)+"-" + arrayList.get(3)+"-"+answer);
					int question_no = set();
					bw.close();
				}
				catch(IOException err)
				{ System.out.print(err);}
				// Storing Answer

				/// Declaration
				jl2.setText(count-1 + "Question added");
				jl1.setText("Give me Question ->"+" "+ (count));
				jt1.setText("");
				al1.setText("");
				al2.setText("");
				al3.setText("");
				al4.setText("");
				rb1.setLabel("Option1");
				rb2.setLabel("Option2");
				rb3.setLabel("Option3");
				rb4.setLabel("Option4");
				
			}
		});
		
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				finish = 1;
				String text = jt1.getText();
				ArrayList<String> arrayList = new ArrayList<String>();
				arrayList.add(rb1.getLabel());
				arrayList.add(rb2.getLabel());
				arrayList.add(rb3.getLabel());
				arrayList.add(rb4.getLabel());
				try{
					FileWriter fw = new FileWriter(str1 + ".txt",true);
					PrintWriter bw = new PrintWriter(fw);
					bw.println(text+"-" + arrayList.get(0) +"-" + arrayList.get(1)+"-" + arrayList.get(2)+"-" + arrayList.get(3)+"-"+answer);
					bw.close();
				}
				catch(IOException err)
				{ System.out.print(err);}
				jl2.setText(count-1 + "Question added");
				set();
			}
		});
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				str1 = jt.getText();
				try(PrintWriter pr = new PrintWriter(new FileWriter("Test_name.txt",true))){
					pr.println(str1);
				}
				catch(IOException err) {}
				jl.setText("success");
				jb.setBounds(0,0,0,0);
				jt.setBounds(0,0,0,0);
				jl.setBounds(0,0,0,0);
				jl1.setBounds(50,10,200,30);
				jl2.setBounds(50,100,200,30);
				jt1.setBounds(50,50,450,50);
				b1.setBounds(100,350,95,30);
				b2.setBounds(250,350,95,30);
				rb1.setBounds(100,120,95,30);  al1.setBounds(200,120,100,30); insertb1.setBounds(150,300,150,30);
				rb2.setBounds(100,160,95,30);	al2.setBounds(200,160,100,30);
				rb3.setBounds(100,200,95,30);	al3.setBounds(200,200,100,30);
				rb4.setBounds(100,240,95,30);	al4.setBounds(200,240,100,30);
			}
		});
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				System.exit(0);
			}
		});
		setSize(500,500);
		setLayout(null);
		setVisible(true);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we){
				System.exit(0);
			}
		});
	}
	void Start(){
		jl = new JLabel(" Give a Test name?");
		jl.setBounds(150,100,150,50);
		add(jl);
		jt = new JTextField();
		jt.setBounds(150,140,120,50);
		add(jt);
		jb = new JButton("OK");
		jb.setBounds(150,200,95,50);
		add(jb);
		
	}
	int set(){
		if(finish == 1) {
			jl1.setBounds(0,0,0,0);
			jl2.setBounds(0,0,0,0);
			jt1.setBounds(0,0,0,0);
			jl3.setBounds(150,150,300,30);
			b1.setBounds(0,0,0,0);
			rb1.setBounds(0,0,0,0);  al1.setBounds(0,0,0,0); insertb1.setBounds(0,0,0,0);
			rb2.setBounds(0,0,0,0);  al2.setBounds(0,0,0,0);
			rb3.setBounds(0,0,0,0);  al3.setBounds(0,0,0,0);
			rb4.setBounds(0,0,0,0);  al4.setBounds(0,0,0,0);
			
			b.setBounds(150,200,300,30);
			
			add(jl3); add(b);
			b2.setBounds(0,0,0,0);
			jl3.setText("Thank you");
			add(jl3);
			String name =" ";
			int permission = 0;
			try{
				
				
				BufferedReader br = new BufferedReader(new FileReader("CreateQuiz.files.txt"));
				while((name = br.readLine()) != null){
					if(name.equals(str1)){
						permission = 1;
					}
				}
				br.close();
				if(permission == 0){
					FileWriter fw = new FileWriter("CreateQuiz.files.txt",true);
					BufferedWriter bw = new BufferedWriter(fw);
					bw.write(str1 + "\n");
					bw.close();
				}
			}
			catch(IOException err)
			{ System.out.print(err);};
		}
		return count++;
	}
	public void itemStateChanged(ItemEvent e){
		if(rb1.getState() == true){
			answer = "1";
		}
		if(rb2.getState() == true){
			answer = "2";
		}
		if(rb3.getState() == true){
			answer = "3";
		}
		if(rb4.getState() == true){
			answer = "4";
		}
	}
	
	public void actionPerformed(ActionEvent e) {}
	
	public static void main(String[] creatingQuiz) throws Exception {
		new CreateQuiz();
	}
}
