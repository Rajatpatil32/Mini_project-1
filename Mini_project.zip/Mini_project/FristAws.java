import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;
public class FristAws extends JFrame implements ActionListener{
	//JFrame jf = new JFrame("New one");
	JTextField jt1;
	JPasswordField jt2;
	JLabel jl1,jl2;//jl3;
	FristAws(){
	jl1 = new JLabel("Username");
	jl1.setBounds(150,100,95,30);
	jl2 = new JLabel("Password");
	jl2.setBounds(150,130,95,30);
	/*jl3 = new JLabel();
	jl3.setBounds(150,300,95,30);*/
	jt1 = new JTextField();
	jt1.setBounds(250,100,95,30);
	jt2 = new JPasswordField();
	jt2.setBounds(250,130,95,30);
	JButton b1 = new JButton("Login");
	b1.setBounds(160,170,95,30);
	b1.addActionListener(this);
	add(b1);
	add(jl1); add(jl2); //add(jl3);
	add(jt1);
	add(jt2);
	setSize(500,500);
	setLayout(null);
	setVisible(true);
	}
		//JOptionPane.showMessageDialog(this,"Succesfull logged in");
	public void actionPerformed(ActionEvent e){
		if(jt1.getText().equalsIgnoreCase("Rajat Patil") && jt2.getText().equalsIgnoreCase("Mypassword")){
			JOptionPane.showMessageDialog(this,"Succesfully logged in");
			setVisible(false);
			SelectTest st = new SelectTest();
		}
		else{
			JOptionPane.showMessageDialog(this,"InValid emailid password");
		}
	}
	public static void main(String[] args){
		new FristAws();
		
	}
}																																	
