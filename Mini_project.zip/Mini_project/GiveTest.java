import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.util.*;
class GiveTest extends JFrame implements ItemListener,ActionListener{
	JLabel jl1,jl2,jl3;
	JTextField jt1;
	int question = 0,count = 0,point=0;
	String answer =" ";
	String Screte_no = "",no = "";
	//JRadioButton rb1,rb2,rb3,rb4;
	JButton b1,b2,b3,b4,end;
	Checkbox rb1,rb2,rb3,rb4;
	//String filename = "";
	String str = " ";
	GiveTest(String filename){
		ArrayList<String> arr = new ArrayList<String>();
		//ArrayList<String> str = new ArrayList<String>();
		try{
			
			FileReader fr = new FileReader(filename + ".txt");
			BufferedReader br = new BufferedReader(fr);
			while((str = br.readLine()) != null){
				if(str.isEmpty()){ continue;}
				else{
					arr.add(str);
					count++;
				}
			}
			
			br.close();
		}catch(Exception e){};
		jl1 = new JLabel("Are sure to give test for resceptive!!!!");
		jl1.setBounds(100*2,150*2,300,30);
		add(jl1);
		jl2=new JLabel();
		jt1 = new JTextField();
		b1 = new JButton("Ready");
		b1.setBounds(200*2,200*2,100,30);
		b2 = new JButton("Next");
		b3 = new JButton("See Score");
		b4 = new JButton("OK");
		end = new JButton("OK");
		add(b1);
		CheckboxGroup cg = new CheckboxGroup();
		//cg.setFont(f);
				rb1 = new Checkbox("Option1",cg,false); rb1.setBounds(100,200,95,30);
				rb2 = new Checkbox("Option2",cg,false); rb2.setBounds(100,240,95,30);
				rb3 = new Checkbox("Option3",cg,false); rb3.setBounds(100,280,95,30);
				rb4 = new Checkbox("Option4",cg,false); rb4.setBounds(100,320,95,30);
				rb1.addItemListener(this);
				rb3.addItemListener(this);
				rb2.addItemListener(this);
				rb4.addItemListener(this);
		addWindowListener(new WindowAdapter(){
					public void windowClosing(WindowEvent we){
						System.exit(0);
					}
				});
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				jl1.setBounds(50*2,20*2,200,30);
				jl2.setBounds(50*2,10*2,200,30);
				//jt1.setBounds(50*2,50*2,400,50);
				b2.setBounds(250,200*2,95,30);
				b1.setBounds(0,0,0,0);
				/////////////////////////////////////////////////
				
				///////////////////////////////////////////////////////////////////////////TextField->>>  add(jt1); 
				add(jl2);
				add(b2);
				add(rb1); add(rb2); add(rb3); add(rb4);
				set();
				String fullString = arr.get(question);
				String[] ques = fullString.split("-");
				rb1.setLabel(ques[1]);
				rb2.setLabel(ques[2]);
				rb3.setLabel(ques[3]);
				rb4.setLabel(ques[4]);
				Screte_no = ques[5];
				
				jl1.setText(ques[0]);
				/////////////////////////////////////////////
			}
		});
		b2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Score();
				set();
				if(question >= count) {
					jl1.setBounds(0,0,0,0);
					//jt1.setBounds(0,0,0,0);
					b2.setBounds(0,0,0,0);
					b3.setBounds(200*2,200*2,150,30);
					add(b3);
					jl2.setBounds(100*2,100*2,250,30);
					jl2.setText("Thank you for Giving test With us");
					rb1.setBounds(0,0,0,0);
					rb2.setBounds(0,0,0,0);
					rb3.setBounds(0,0,0,0);
					rb4.setBounds(0,0,0,0);
				}
				String fullString = arr.get(question);
				String[] ques = fullString.split("-");
				rb1.setLabel(ques[1]);
				rb2.setLabel(ques[2]);
				rb3.setLabel(ques[3]);
				rb4.setLabel(ques[4]);
				Screte_no = ques[5];
				String str = " ";
				try{
					PrintWriter bw = new PrintWriter(new FileWriter(filename+".answer.txt",true));
					
					str=" ";
					if(no == "1"){
						str = ques[1];
					}
					else if(no == "2"){
						str = ques[2];
					}
					else if(no == "3"){
						str = ques[3];
					}
					else if(no == "4"){
						str = ques[4];
					}
					else{
						str = "NOT ANSWERED";
					}
					bw.println(str);
					bw.close();
					//jt1.setText(" ");
					jl1.setText(ques[0]);
				}
				catch(IOException error){};
			}
		});
		b3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Score();;
				b3.setBounds(0,0,0,0);
				jl2.setText("Your Score = "+point);	
				jl2.setBounds(200*2,150*2,150,30);
				add(jl2);
				end.setBounds(200*2,200*2,100,30);
				add(end);
			}
		});
		end.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				System.exit(0);
			}
		});
		b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			}
		});
		setSize(500*2,500*2);
		setLayout(null);
		setVisible(true);
	}
	void Score(){
		if(no.equals(Screte_no)){
			point++;
		}
	}
	void set(){
		if(question - 1 == count){
			b2.setLabel("Submit");
		}
		question++;
	}
	public void itemStateChanged(ItemEvent e){
		if(rb1.getState() == true){
			no = "1";
		}
		if(rb2.getState() == true){
			no = "2";
		}
		if(rb3.getState() == true){
			no = "3";
		}
		if(rb4.getState() == true){
			no = "4";
		}
	}
	public void actionPerformed(ActionEvent e){}
	public static void main(String[] givingtest){
		new GiveTest("");
	}
}
