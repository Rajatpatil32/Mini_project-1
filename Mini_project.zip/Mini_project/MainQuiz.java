import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
public class MainQuiz extends JFrame {
	JTextField jt1;
	JLabel jl1,jl2;
	JComboBox jc;
	JButton b1;
	int N;
	MainQuiz(){
		jl1 = new JLabel("Give Number of Question");
		jl1.setBounds(150,100,200,50);
		
		jl2 = new JLabel("");
		jl2.setBounds(150,200,95,50);
		
		jt1 = new JTextField();
		jt1.setBounds(350,110,95,30);
		
		/*String arr[] = {"2,","5","10",""};
		jc = new JComboBox(arr);
		jc.setBounds(350,110,95,30);*/
		
		b1 = new JButton("ok");
		b1.setBounds(200,150,95,30);
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				jt1.setEditable(false);
				jl2.setText(""+N);
				CreateQuiz cq = new CreateQuiz(N);
				try{
					CreateQuiz c = new CreateQuiz();
				}
				catch(IOException er){System.out.println(er);}
			}
		});
		//add(jc);
		add(b1); add(jt1); add(jl1);
		add(jl2);
		setSize(500,500);
		setLayout(null);
		jt1.addKeyListener(new KeyAdapter() {
         		public void keyPressed(KeyEvent ke) {
         		   String value = jt1.getText();
         		   //int l = value.length();
         		   if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9') {
         		      jt1.setEditable(true);
         		      jl2.setText("");
         		   } else {
         		      jt1.setEditable(false);
         		      jl2.setText("* Enter only numeric digits(0-9)");
        		   }
        		   //N = Integer.parseInt(value);
        		   set(value);
         		}
		});
		setVisible(true);
	}
	void set(String str){
		N = Integer.parseInt(str);
	}
	
	public static void main(String[] args) throws Exception {
		new MainQuiz();
	}
}
