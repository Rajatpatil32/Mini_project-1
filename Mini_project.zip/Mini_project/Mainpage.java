import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
public class Mainpage extends JFrame implements ActionListener{
	JRadioButton b1,b2;
	JButton B;
	Mainpage(){
		b1 = new JRadioButton("Create a test");
		b1.setBounds(80,150,150,50);
		//b1.addActionListener(this);
		b2 = new JRadioButton("Want to give test");
		b2.setBounds(250,150,150,50);
		B = new JButton("OK");
		B.setBounds(170,200,150,50);
		B.addActionListener(this);
		ButtonGroup bg=new ButtonGroup();
		add(B);
		bg.add(b1); bg.add(b2);
		add(b1); add(b2);
		setSize(500,500);
		setLayout(null);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e){
		if(b1.isSelected()){
			setVisible(false);
			try{
				
				CreateQuiz cq = new CreateQuiz();
			}
			catch(IOException er){
				System.out.println(er);
			}
		}
		if(b2.isSelected()){
			setVisible(false);
			FristAws fA = new FristAws(); 
		}
	}
	public static void main(String[] MainPage){
		new Mainpage();
	}
}

