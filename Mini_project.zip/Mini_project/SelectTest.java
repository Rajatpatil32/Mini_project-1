import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
class SelectTest extends JFrame implements ActionListener{
	SelectTest(){
		JLabel jl;
		JButton b;
		jl = new JLabel("Select test that you want to give.");
		jl.setBounds(30*2,100*2,200*2,30);
		b = new JButton("OK");
		b.setBounds(30*2,120*2,95,30);
		add(b);
		add(jl);
		final DefaultListModel<String> list = new DefaultListModel<>();
		try{
			String line = "";
			int i=0;
			BufferedReader br =new BufferedReader(new FileReader("Test_name.txt"));
			while((line = br.readLine()) != null){
				list.addElement(line);
			}
		}
		catch(IOException e) {}
		final JList<String> list1 = new JList<>(list);
		list1.setBounds(100*2,100*2,75,30);
		//ch.setBounds(100*2,100*2,95*2,30);
		add(list1);
		setSize(500*2,500*2);
		setVisible(true);
		setLayout(null);
		addWindowListener(new WindowAdapter(){
					public void windowClosing(WindowEvent we){
						System.exit(0);
					}
				});
		b.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				if(list1.getSelectedIndex() != -1){
					GiveTest gt =new GiveTest(list1.getSelectedValue());
				}
			}
		});
	}
	public void actionPerformed(ActionEvent e) {}
	public static void main(String[] args){
		new SelectTest();
	}
}
